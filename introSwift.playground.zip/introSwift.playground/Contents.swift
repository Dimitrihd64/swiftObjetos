import UIKit

//hacer coment
/*
 multilinea
 
    -swift- Basado en c++
        Lo mejor de los modernos/se queda con las cosas viejas utiles
    ->Lenguaje sencillo de aprender y programar
    ->Lenguaje sencillo - NullSafety (nil)
    ->No existen los tipos primitivos(todo son oobjetos, no exixte los tipos de variables)
    ->Acepta inferencia de tipos ->El tipado y fuertemente tipado
    ->se la suda public y private
    
    Int - No se necesita la palabra new ->  x = Int()
    Float
    String
    Double
    Bool
 
 */

//VAR NOMBRE_DATO:TIPO_DATO=DATO
// let CONSTANTE :TIPO_DATO = DATO

var NUMERO : Int = 12
var PALABRA:String="HOLAMUNDO"
var num=12
var pal = "holamundo"
let cons = 10 //no se pueden cambiar el valor

//optionals - UnWrap
var opcional : String?
opcional = "holamundo"
print(opcional!)

/*
 +,-,*,/,%
 ya no existe ++, --
 se utiliza ->  + = 1
 
 
 */
var srt = "el numero \(num)"
print(srt)
/*
 no existe fori
 Rangos Inicio...Fin

 */
0...9
for x in 0...9{
    print(x)
}

if true {
    print(num)
}

//Tupla
var tupla = ( nombre:"alex", apellidos:"ros", edad:20)
//ENUM
enum info{
    case persona
    case perro
    case gato
}
var tipoAnimal = info.perro

//ARRAYS
var numerosList : [Int] = []
var numerosList2=[1,2,3,4]
numerosList2.count
numerosList2.reverse()
numerosList2.append(10)
numerosList2.append(contentsOf: [4,5,7])
numerosList2.insert(7, at: 2)
numerosList2.sort()
//numerosList2.removeAll()
numerosList2.first
numerosList2.last
//numerosList2.removeFirst()
//numerosList2.removeLast()
for  item in numerosList2 {
    print(item)
    
}
for (interador, valor) in numerosList2.enumerated(){
    print("posicion :\(interador) valor: \(valor)")
    
}
//Estructuras
struct Persona{
    var nombre:String
    var apellidos : String
    var edad : Int
}
var p1 = Persona (nombre: "alex", apellidos: "ros", edad: 20)
var personasList : [Persona]=[]


//clases
class Reloj{
    var marca : String
    var modelo : String
    var precio : Double
    var digital : Bool
    init(<#parameters#>) {
        self.marca=""
        self.modelo=""
        self.precio=0
        self.digital=false
    }
    init(marca: String,modelo:String,precio:Double,digital:Bool) {
        self.marca=marca
        self.modelo=modelo
        self.precio=precio
        self.digital=digital
        
    }
    convenience init(marca:String, digital:Bool) {
        self.init(marca: marca,modelo:"sin modelo",precio:0,digital:digital)
        
    }
    func getMarca() -> String {
        return self.marca
    }
    func setMarca(marca:String){
        self.marca=marca
    }
}

var r1 = Reloj(marca: <#T##String#>, modelo: <#T##String#>, precio: <#T##Double#>, digital: <#T##Bool#>)
var r2 = Reloj(marca: <#T##String#>, digital: <#T##Bool#>)
