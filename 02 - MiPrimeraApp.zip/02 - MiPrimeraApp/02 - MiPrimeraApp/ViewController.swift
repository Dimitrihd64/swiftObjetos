//
//  ViewController.swift
//  02 - MiPrimeraApp
//
//  Created by Alejandro De Ros on 25/11/2022.
//

import UIKit

class ViewController: UIViewController {
    
    @IBOutlet weak var txtMarca: UITextField!
    @IBOutlet weak var txtModelo: UITextField!
    @IBOutlet weak var txtPrecio: UITextField!
    @IBOutlet weak var swDigital: UISwitch!
    @IBOutlet weak var lbInfoReloj: UILabel!
    var relojesList: [RelojStruct] = []
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        lbInfoReloj.text="tenemos estos relojes: \(relojesList.count)"
    }

    
    @IBAction func btnCrearRelojClick(_ sender: Any) {
        let marca = txtMarca.text!
        let modelo = txtModelo.text!
        let precioT = txtPrecio.text!
        let digital = swDigital.isOn
        
        let precio : Double = precioT.isEmpty ? 0.0 : Double(precioT)!
        let Reloj = RelojStruct(marca: marca, modelo: modelo, precio: precio, digital: digital)
        
        relojesList.append(Reloj)
        lbInfoReloj.text="tenemos estos relojes: \(relojesList.count)"
        
    }
    
}

