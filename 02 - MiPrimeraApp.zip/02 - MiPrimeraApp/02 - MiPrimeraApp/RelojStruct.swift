//
//  RelojStruct.swift
//  02 - MiPrimeraApp
//
//  Created by Alejandro De Ros on 25/11/2022.
//

import Foundation

struct RelojStruct {
    var marca:String
    var modelo:String
    var precio:Double
    var digital:Bool
}
